
function openAdmin() {
  document.getElementById("adminSection").classList.remove("hidden");
  document.getElementById("viewerSection").classList.add("hidden");
}

function enterRoom() {
  document.getElementById("viewerSection").classList.remove("hidden");
  document.getElementById("adminSection").classList.add("hidden");
}

function createRoom() {
  const code = document.getElementById("adminCode").value;
  if (code === "admin2025") {
    alert("تم إنشاء غرفة بإشرافك.");
    // من هنا نقدر نضيف تحكم الغرفة لاحقاً
  } else {
    alert("رمز خاطئ");
  }
}

function joinRoom() {
  const roomCode = document.getElementById("roomCode").value;
  alert("تم دخولك الغرفة برمز: " + roomCode);
  // مستقبلاً نربطها بسيرفر أو Firebase
}
